﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ACTMULTILib;
using MITSUBISHI.Component;

namespace RMV_PLC
{

struct PLC_Val
{

    public int RMV_Open1;
    public int PC_Read1;
    public string Str_1;
    public string Str_2;
      


}
class PLC_Ref
{
    public int[] PLC_Data { get; set; }
    public int PLC_Data_length { get; set; }
    public char[] Char_arr { get; set; }
    public string Device_Start { get; set; }
    public string Device_Lot_Input { get; set; }
    public string Device_Edit_Don { get; set; }
    public int PLC_Data_bit;
    public PLC_Ref()
        {
            this.PLC_Data_length = 5;
            this.PLC_Data = new int[PLC_Data_length];
            this.Device_Start = "M8001";
            this.Device_Lot_Input = "M8002";
            this.Device_Edit_Don = "M8004";
            this.PLC_Data_bit = 1;

        }
      
}




    public partial class Form1 : Form
    {
        ActEasyIF acteasyif;
        PLC_Val V = new PLC_Val();
        PLC_Ref R = new PLC_Ref();

        public Form1()
        {
            InitializeComponent();
            acteasyif.ActLogicalStationNumber = 52;
            acteasyif = new ActEasyIF();
            V.Str_2 = "";
            Array.Clear(R.PLC_Data, 0, R.PLC_Data_length);
           
        }

   
      

        //PLC Connect
        private void button1_Click(object sender, EventArgs e)
        {
            

            try
            {
                V.RMV_Open1 = acteasyif.Open();

                if (V.RMV_Open1 != 0)
                {
                    Error_code.Text = "RMV Connect Error" + V.RMV_Open1;
                }

            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
        }
        //PLC DIs Connect
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                acteasyif.Close();
            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
        }

        //WriteDeviceBlock

        private void ID_Throw_Block()
        {
            V.Str_1 = Error_code.Text;
            V.RMV_Open1 = 0;
            Array.Clear(R.PLC_Data, 0, R.PLC_Data_length);

            for (int i = 0; i < R.PLC_Data_length; i++)
            {
                R.Char_arr[i] = V.Str_1[i];
                R.PLC_Data[i] = Convert.ToInt32(R.Char_arr[i]);

            }
            V.RMV_Open1 = acteasyif.WriteDeviceBlock(R.Device_Lot_Input, R.PLC_Data_length, ref R.PLC_Data[0]);

        }

        //PC_PLC Write Data

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ID_Throw_Block();
            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
            

        }
    
        private void ID_Throw_bit()
        {
            V.RMV_Open1 = 0;
            V.RMV_Open1 = acteasyif.SetDevice(R.Device_Start, R.PLC_Data_bit);

            if (V.RMV_Open1 != 0)
            {
                label2.Text = "SetDevice Error   " + V.RMV_Open1.ToString();
            }
            Bit_val.Text = R.Device_Start + " lot 정보요청확인 " + " Set";

        }
        private void ID_Catch_bit()
        {
            V.RMV_Open1 = 0;
            V.RMV_Open1 = acteasyif.GetDevice(R.Device_Start, out R.PLC_Data_bit);

            if (V.RMV_Open1 != 0)
            {
                Error_code.Text = "GetDevice Error" + V.RMV_Open1.ToString();
            }
            Bit_val.Text = R.Device_Start + " lot 정보요구" + R.PLC_Data_bit + "Get";



        }
        private void ID_Catch_Block() //ReadDeviceBlock  
        {
            V.RMV_Open1 = 0;
            Array.Clear(R.PLC_Data, 0, R.PLC_Data_length);
            V.RMV_Open1 = acteasyif.ReadDeviceBlock(R.Device_Lot_Input, R.PLC_Data_length, out R.PLC_Data[0]);

            if (V.RMV_Open1 != 0)
            {
                Error_code.Text = "DGM PC Error " + V.RMV_Open1;
            }
            else if (V.RMV_Open1 == 0)
            {
                for (int i = 0; i < R.PLC_Data_length; i++)
                {
                    V.Str_2 += Convert.ToChar(R.PLC_Data[i]);
                }
                Read_Dv.Text = V.Str_2;


            }
        }


        //ReadDeviceBlock
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                ID_Catch_Block();
            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                ID_Catch_bit();
            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                ID_Throw_bit();
            }
            catch (IndexOutOfRangeException ex)
            {
                throw new IndexOutOfRangeException("Connect Out Of Range", ex);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void OpenError_Click(object sender, EventArgs e)
        {

        }

        private void Read_Dv_Click(object sender, EventArgs e)
        {

        }

        private void Get_dv_Click(object sender, EventArgs e)
        {

        }
    }
}
